READER FILES
============
The files in this folder, \ReaderFiles\, contain both source code
and executable code for the example programs presented in the text
of "Data Structures and Algorithms in Java," 2nd Edition. They are
available to any reader of the book.

The source code is in the form of .java files. They can be compiled
with the "javac" command in Sun's JDK.

The .class files were compiled with Sun's JDK 1.4. They can be
executed by applying the "java" command to whichever .class file
ends in "App" (for example, ArrayApp.class).

See Appendix A for more information. 

